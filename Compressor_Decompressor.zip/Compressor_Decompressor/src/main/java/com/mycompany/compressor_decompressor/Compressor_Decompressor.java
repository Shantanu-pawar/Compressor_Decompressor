/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.compressor_decompressor;

/**
 *
 * @author ADMIN
 */
public class Compressor_Decompressor {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
